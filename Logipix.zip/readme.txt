Tests are done in test.java:

Used methods and how to use them :

- logipix puzzle1 = new logipix("LogiX.txt"); 
=> to initialize a logipix

- logipix.printb(puzzle0.setOfBrokenLines(new int[] { 0, 0 })); 
=> uses a method printb that prints a LinkedList<LinkedList<int[]>> this will print all the brokenlines going from the cell (0,0) of the puzzle in test.txt

- System.out.println(puzzle1); 
=> prints the puzzle every cell is like [cell|state] (state=0,1 or 2 see description in the top of logipix.java)

- puzzle0.combinationAndExclusion(true); 
=> does combinationAndExclusion over puzzle0 draws a preview of the solution when finished if the argument is true, and in both cases true/false it fills a hashMap of useful brokenlines of each cell which is an attribute of puzzle0 and which will be used in quest 7 (so must call this one before caling optimalSolve() !!)

puzzle2.optimisedSolve();
=> solves using only useful brokenLines (means left brokenLines after exclusion) and draws the solution when finished
(note that drawing a solution is diffrent from printing it see decription in the top of logipix.java)

puzzle2.solve();
=> solves using normal backtracking on all possible brokenLines
